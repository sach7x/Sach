

```python
# 3 trends
#Capomulin was the only drug (of the 2 drugs we had to consider+placebo) that led to overall tumor shrinkage (-19.4%)
#The other 2 drugs+placebo led to further tumor growth, with Ketapril treated mice showing the greatest overall tumor growth (+57.0%)
#Capomulin had the most amount of surviving mice (n=21) at the end of the 45 timepoint, and Infubinol had the least amount of surviving mice (n=9)

```


```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
```


```python
file = pd.read_csv('clinicaltrial_data.csv')
clinicaltrial_df = pd.DataFrame(file)
```


```python
clinicaltrial_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Mouse ID</th>
      <th>Timepoint</th>
      <th>Tumor Volume (mm3)</th>
      <th>Metastatic Sites</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>b128</td>
      <td>0</td>
      <td>45.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>f932</td>
      <td>0</td>
      <td>45.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>g107</td>
      <td>0</td>
      <td>45.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>a457</td>
      <td>0</td>
      <td>45.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>c819</td>
      <td>0</td>
      <td>45.0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
mouse_file = pd.read_csv('mouse_drug_data.csv')
mouse_df= pd.DataFrame(mouse_file)
```


```python
mouse_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Mouse ID</th>
      <th>Drug</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>f234</td>
      <td>Stelasyn</td>
    </tr>
    <tr>
      <th>1</th>
      <td>x402</td>
      <td>Stelasyn</td>
    </tr>
    <tr>
      <th>2</th>
      <td>a492</td>
      <td>Stelasyn</td>
    </tr>
    <tr>
      <th>3</th>
      <td>w540</td>
      <td>Stelasyn</td>
    </tr>
    <tr>
      <th>4</th>
      <td>v764</td>
      <td>Stelasyn</td>
    </tr>
  </tbody>
</table>
</div>




```python
set(mouse_df['Drug'])
```




    {'Capomulin',
     'Ceftamin',
     'Infubinol',
     'Ketapril',
     'Naftisol',
     'Placebo',
     'Propriva',
     'Ramicane',
     'Stelasyn',
     'Zoniferol'}




```python
combined_df = pd.merge(clinicaltrial_df, mouse_df, on='Mouse ID', how='inner')
combined_df = combined_df.sort_values('Timepoint', ascending=True)
combined_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Mouse ID</th>
      <th>Timepoint</th>
      <th>Tumor Volume (mm3)</th>
      <th>Metastatic Sites</th>
      <th>Drug</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>b128</td>
      <td>0</td>
      <td>45.0</td>
      <td>0</td>
      <td>Capomulin</td>
    </tr>
    <tr>
      <th>1535</th>
      <td>i635</td>
      <td>0</td>
      <td>45.0</td>
      <td>0</td>
      <td>Propriva</td>
    </tr>
    <tr>
      <th>565</th>
      <td>g791</td>
      <td>0</td>
      <td>45.0</td>
      <td>0</td>
      <td>Ramicane</td>
    </tr>
    <tr>
      <th>1545</th>
      <td>w746</td>
      <td>0</td>
      <td>45.0</td>
      <td>0</td>
      <td>Propriva</td>
    </tr>
    <tr>
      <th>1547</th>
      <td>r107</td>
      <td>0</td>
      <td>45.0</td>
      <td>0</td>
      <td>Propriva</td>
    </tr>
  </tbody>
</table>
</div>




```python
combined_df.reset_index(inplace=True, drop=True)
combined_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Mouse ID</th>
      <th>Timepoint</th>
      <th>Tumor Volume (mm3)</th>
      <th>Metastatic Sites</th>
      <th>Drug</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>b128</td>
      <td>0</td>
      <td>45.0</td>
      <td>0</td>
      <td>Capomulin</td>
    </tr>
    <tr>
      <th>1</th>
      <td>i635</td>
      <td>0</td>
      <td>45.0</td>
      <td>0</td>
      <td>Propriva</td>
    </tr>
    <tr>
      <th>2</th>
      <td>g791</td>
      <td>0</td>
      <td>45.0</td>
      <td>0</td>
      <td>Ramicane</td>
    </tr>
    <tr>
      <th>3</th>
      <td>w746</td>
      <td>0</td>
      <td>45.0</td>
      <td>0</td>
      <td>Propriva</td>
    </tr>
    <tr>
      <th>4</th>
      <td>r107</td>
      <td>0</td>
      <td>45.0</td>
      <td>0</td>
      <td>Propriva</td>
    </tr>
  </tbody>
</table>
</div>




```python
drug_group = combined_df[['Timepoint','Tumor Volume (mm3)','Drug']]
drug_group = drug_group.groupby(['Drug','Timepoint']).mean()
drug_group.head()

```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>Tumor Volume (mm3)</th>
    </tr>
    <tr>
      <th>Drug</th>
      <th>Timepoint</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="5" valign="top">Capomulin</th>
      <th>0</th>
      <td>45.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>44.266086</td>
    </tr>
    <tr>
      <th>10</th>
      <td>43.084291</td>
    </tr>
    <tr>
      <th>15</th>
      <td>42.064317</td>
    </tr>
    <tr>
      <th>20</th>
      <td>40.716325</td>
    </tr>
  </tbody>
</table>
</div>




```python
drug_group_sem = combined_df[['Timepoint','Tumor Volume (mm3)','Drug']]
drug_group_sem = drug_group_sem.groupby(['Drug','Timepoint']).sem()
drug_group_sem.head()

```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>Tumor Volume (mm3)</th>
    </tr>
    <tr>
      <th>Drug</th>
      <th>Timepoint</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="5" valign="top">Capomulin</th>
      <th>0</th>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>0.448593</td>
    </tr>
    <tr>
      <th>10</th>
      <td>0.702684</td>
    </tr>
    <tr>
      <th>15</th>
      <td>0.838617</td>
    </tr>
    <tr>
      <th>20</th>
      <td>0.909731</td>
    </tr>
  </tbody>
</table>
</div>




```python
capomulin_sem = drug_group_sem['Tumor Volume (mm3)'].loc['Capomulin',:]
capomulin_sem
```




    Drug       Timepoint
    Capomulin  0            0.000000
               5            0.448593
               10           0.702684
               15           0.838617
               20           0.909731
               25           0.881642
               30           0.934460
               35           1.052241
               40           1.223608
               45           1.223977
    Name: Tumor Volume (mm3), dtype: float64




```python
infubinol_sem = drug_group_sem['Tumor Volume (mm3)'].loc['Infubinol',:]
infubinol_sem.head()
```




    Drug       Timepoint
    Infubinol  0            0.000000
               5            0.235102
               10           0.282346
               15           0.357705
               20           0.476210
    Name: Tumor Volume (mm3), dtype: float64




```python
ketapril_sem = drug_group_sem['Tumor Volume (mm3)'].loc['Ketapril',:]
ketapril_sem.head()
```




    Drug      Timepoint
    Ketapril  0            0.000000
              5            0.264819
              10           0.357421
              15           0.580268
              20           0.726484
    Name: Tumor Volume (mm3), dtype: float64




```python
placebo_sem = drug_group_sem['Tumor Volume (mm3)'].loc['Placebo',:]
placebo_sem.head()
```




    Drug     Timepoint
    Placebo  0            0.000000
             5            0.218091
             10           0.402064
             15           0.614461
             20           0.839609
    Name: Tumor Volume (mm3), dtype: float64




```python
drug_group_sem.dtypes
```




    Tumor Volume (mm3)    float64
    dtype: object




```python
#tumor size over time
drug_group = drug_group.pivot_table(index='Timepoint', columns='Drug')
drug_group.columns = drug_group.columns.droplevel()
drug_group
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Drug</th>
      <th>Capomulin</th>
      <th>Ceftamin</th>
      <th>Infubinol</th>
      <th>Ketapril</th>
      <th>Naftisol</th>
      <th>Placebo</th>
      <th>Propriva</th>
      <th>Ramicane</th>
      <th>Stelasyn</th>
      <th>Zoniferol</th>
    </tr>
    <tr>
      <th>Timepoint</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>45.000000</td>
      <td>45.000000</td>
      <td>45.000000</td>
      <td>45.000000</td>
      <td>45.000000</td>
      <td>45.000000</td>
      <td>45.000000</td>
      <td>45.000000</td>
      <td>45.000000</td>
      <td>45.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>44.266086</td>
      <td>46.503051</td>
      <td>47.062001</td>
      <td>47.389175</td>
      <td>46.796098</td>
      <td>47.125589</td>
      <td>47.248967</td>
      <td>43.944859</td>
      <td>47.527452</td>
      <td>46.851818</td>
    </tr>
    <tr>
      <th>10</th>
      <td>43.084291</td>
      <td>48.285125</td>
      <td>49.403909</td>
      <td>49.582269</td>
      <td>48.694210</td>
      <td>49.423329</td>
      <td>49.101541</td>
      <td>42.531957</td>
      <td>49.463844</td>
      <td>48.689881</td>
    </tr>
    <tr>
      <th>15</th>
      <td>42.064317</td>
      <td>50.094055</td>
      <td>51.296397</td>
      <td>52.399974</td>
      <td>50.933018</td>
      <td>51.359742</td>
      <td>51.067318</td>
      <td>41.495061</td>
      <td>51.529409</td>
      <td>50.779059</td>
    </tr>
    <tr>
      <th>20</th>
      <td>40.716325</td>
      <td>52.157049</td>
      <td>53.197691</td>
      <td>54.920935</td>
      <td>53.644087</td>
      <td>54.364417</td>
      <td>53.346737</td>
      <td>40.238325</td>
      <td>54.067395</td>
      <td>53.170334</td>
    </tr>
    <tr>
      <th>25</th>
      <td>39.939528</td>
      <td>54.287674</td>
      <td>55.715252</td>
      <td>57.678982</td>
      <td>56.731968</td>
      <td>57.482574</td>
      <td>55.504138</td>
      <td>38.974300</td>
      <td>56.166123</td>
      <td>55.432935</td>
    </tr>
    <tr>
      <th>30</th>
      <td>38.769339</td>
      <td>56.769517</td>
      <td>58.299397</td>
      <td>60.994507</td>
      <td>59.559509</td>
      <td>59.809063</td>
      <td>58.196374</td>
      <td>38.703137</td>
      <td>59.826738</td>
      <td>57.713531</td>
    </tr>
    <tr>
      <th>35</th>
      <td>37.816839</td>
      <td>58.827548</td>
      <td>60.742461</td>
      <td>63.371686</td>
      <td>62.685087</td>
      <td>62.420615</td>
      <td>60.350199</td>
      <td>37.451996</td>
      <td>62.440699</td>
      <td>60.089372</td>
    </tr>
    <tr>
      <th>40</th>
      <td>36.958001</td>
      <td>61.467895</td>
      <td>63.162824</td>
      <td>66.068580</td>
      <td>65.600754</td>
      <td>65.052675</td>
      <td>63.045537</td>
      <td>36.574081</td>
      <td>65.356386</td>
      <td>62.916692</td>
    </tr>
    <tr>
      <th>45</th>
      <td>36.236114</td>
      <td>64.132421</td>
      <td>65.755562</td>
      <td>70.662958</td>
      <td>69.265506</td>
      <td>68.084082</td>
      <td>66.258529</td>
      <td>34.955595</td>
      <td>68.438310</td>
      <td>65.960888</td>
    </tr>
  </tbody>
</table>
</div>




```python
sns.set()
drug_group.plot(linestyle='dashed',marker='o', legend='best', figsize=(10,8), )
#yerr=drug_group_std
plt.show()
```


![png](output_17_0.png)



```python

plt.figure(figsize=(12,8))
plt.errorbar(x=drug_group.index,y=drug_group['Capomulin'], yerr=capomulin_sem, color='r', marker='o', markersize=5, linestyle='dashed', linewidth=0.50)
plt.errorbar(x=drug_group.index,y=drug_group['Infubinol'], yerr=infubinol_sem, color='b', marker='^', markersize=5, linestyle='dashed', linewidth=0.50)
plt.errorbar(x=drug_group.index,y=drug_group['Ketapril'], yerr=ketapril_sem, color='g', marker='s', markersize=5, linestyle='dashed', linewidth=0.50)
plt.errorbar(x=drug_group.index,y=drug_group['Placebo'], yerr=placebo_sem, color='k', marker='d', markersize=5, linestyle='dashed', linewidth=0.50)
plt.title('Tumor Response to Treatment')
plt.xlabel('Time (Days)')
plt.ylabel('Tumor Volume (mm3)')
plt.legend(frameon=True)

plt.show()
```


![png](output_18_0.png)



```python
meta_group = combined_df[['Timepoint','Metastatic Sites','Drug']]
meta_group = meta_group.groupby(['Drug','Timepoint']).mean()
meta_group.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>Metastatic Sites</th>
    </tr>
    <tr>
      <th>Drug</th>
      <th>Timepoint</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="5" valign="top">Capomulin</th>
      <th>0</th>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>0.160000</td>
    </tr>
    <tr>
      <th>10</th>
      <td>0.320000</td>
    </tr>
    <tr>
      <th>15</th>
      <td>0.375000</td>
    </tr>
    <tr>
      <th>20</th>
      <td>0.652174</td>
    </tr>
  </tbody>
</table>
</div>




```python
meta_group_sem = combined_df[['Timepoint','Metastatic Sites','Drug']]
meta_group_sem = meta_group_sem.groupby(['Drug','Timepoint']).sem()
meta_group.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>Metastatic Sites</th>
    </tr>
    <tr>
      <th>Drug</th>
      <th>Timepoint</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="5" valign="top">Capomulin</th>
      <th>0</th>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>0.160000</td>
    </tr>
    <tr>
      <th>10</th>
      <td>0.320000</td>
    </tr>
    <tr>
      <th>15</th>
      <td>0.375000</td>
    </tr>
    <tr>
      <th>20</th>
      <td>0.652174</td>
    </tr>
  </tbody>
</table>
</div>




```python
capomulin_met_sem = meta_group_sem['Metastatic Sites'].loc['Capomulin',:]
capomulin_met_sem
```




    Drug       Timepoint
    Capomulin  0            0.000000
               5            0.074833
               10           0.125433
               15           0.132048
               20           0.161621
               25           0.181818
               30           0.172944
               35           0.169496
               40           0.175610
               45           0.202591
    Name: Metastatic Sites, dtype: float64




```python
infubinol_met_sem = meta_group_sem['Metastatic Sites'].loc['Infubinol',:]
infubinol_met_sem
```




    Drug       Timepoint
    Infubinol  0            0.000000
               5            0.091652
               10           0.159364
               15           0.194015
               20           0.234801
               25           0.265753
               30           0.227823
               35           0.224733
               40           0.314466
               45           0.309320
    Name: Metastatic Sites, dtype: float64




```python
ketapril_met_sem = meta_group_sem['Metastatic Sites'].loc['Ketapril',:]
ketapril_met_sem
```




    Drug      Timepoint
    Ketapril  0            0.000000
              5            0.098100
              10           0.142018
              15           0.191381
              20           0.236680
              25           0.288275
              30           0.347467
              35           0.361418
              40           0.315725
              45           0.278722
    Name: Metastatic Sites, dtype: float64




```python
placebo_met_sem = meta_group_sem['Metastatic Sites'].loc['Placebo',:]
placebo_met_sem
```




    Drug     Timepoint
    Placebo  0            0.000000
             5            0.100947
             10           0.115261
             15           0.190221
             20           0.234064
             25           0.263888
             30           0.300264
             35           0.341412
             40           0.297294
             45           0.304240
    Name: Metastatic Sites, dtype: float64




```python
#metastatic sites over time
meta_group = meta_group.pivot_table(index='Timepoint', columns='Drug')
meta_group.columns = meta_group.columns.droplevel()
meta_group

```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Drug</th>
      <th>Capomulin</th>
      <th>Ceftamin</th>
      <th>Infubinol</th>
      <th>Ketapril</th>
      <th>Naftisol</th>
      <th>Placebo</th>
      <th>Propriva</th>
      <th>Ramicane</th>
      <th>Stelasyn</th>
      <th>Zoniferol</th>
    </tr>
    <tr>
      <th>Timepoint</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>0.160000</td>
      <td>0.380952</td>
      <td>0.280000</td>
      <td>0.304348</td>
      <td>0.260870</td>
      <td>0.375000</td>
      <td>0.320000</td>
      <td>0.120000</td>
      <td>0.240000</td>
      <td>0.166667</td>
    </tr>
    <tr>
      <th>10</th>
      <td>0.320000</td>
      <td>0.600000</td>
      <td>0.666667</td>
      <td>0.590909</td>
      <td>0.523810</td>
      <td>0.833333</td>
      <td>0.565217</td>
      <td>0.250000</td>
      <td>0.478261</td>
      <td>0.500000</td>
    </tr>
    <tr>
      <th>15</th>
      <td>0.375000</td>
      <td>0.789474</td>
      <td>0.904762</td>
      <td>0.842105</td>
      <td>0.857143</td>
      <td>1.250000</td>
      <td>0.764706</td>
      <td>0.333333</td>
      <td>0.782609</td>
      <td>0.809524</td>
    </tr>
    <tr>
      <th>20</th>
      <td>0.652174</td>
      <td>1.111111</td>
      <td>1.050000</td>
      <td>1.210526</td>
      <td>1.150000</td>
      <td>1.526316</td>
      <td>1.000000</td>
      <td>0.347826</td>
      <td>0.952381</td>
      <td>1.294118</td>
    </tr>
    <tr>
      <th>25</th>
      <td>0.818182</td>
      <td>1.500000</td>
      <td>1.277778</td>
      <td>1.631579</td>
      <td>1.500000</td>
      <td>1.941176</td>
      <td>1.357143</td>
      <td>0.652174</td>
      <td>1.157895</td>
      <td>1.687500</td>
    </tr>
    <tr>
      <th>30</th>
      <td>1.090909</td>
      <td>1.937500</td>
      <td>1.588235</td>
      <td>2.055556</td>
      <td>2.066667</td>
      <td>2.266667</td>
      <td>1.615385</td>
      <td>0.782609</td>
      <td>1.388889</td>
      <td>1.933333</td>
    </tr>
    <tr>
      <th>35</th>
      <td>1.181818</td>
      <td>2.071429</td>
      <td>1.666667</td>
      <td>2.294118</td>
      <td>2.266667</td>
      <td>2.642857</td>
      <td>2.300000</td>
      <td>0.952381</td>
      <td>1.562500</td>
      <td>2.285714</td>
    </tr>
    <tr>
      <th>40</th>
      <td>1.380952</td>
      <td>2.357143</td>
      <td>2.100000</td>
      <td>2.733333</td>
      <td>2.466667</td>
      <td>3.166667</td>
      <td>2.777778</td>
      <td>1.100000</td>
      <td>1.583333</td>
      <td>2.785714</td>
    </tr>
    <tr>
      <th>45</th>
      <td>1.476190</td>
      <td>2.692308</td>
      <td>2.111111</td>
      <td>3.363636</td>
      <td>2.538462</td>
      <td>3.272727</td>
      <td>2.571429</td>
      <td>1.250000</td>
      <td>1.727273</td>
      <td>3.071429</td>
    </tr>
  </tbody>
</table>
</div>




```python
meta_group.plot(linestyle='dashed',marker='o', legend='best', figsize=(10,8), )
plt.show()
```


![png](output_26_0.png)



```python
#chart metastatic sites with errorbars
plt.figure(figsize=(12,8))
plt.errorbar(x=meta_group.index,y=meta_group['Capomulin'], yerr=capomulin_met_sem, color='r', marker='o', markersize=5, linestyle='dashed', linewidth=0.50)
plt.errorbar(x=meta_group.index,y=meta_group['Infubinol'], yerr=infubinol_met_sem, color='b', marker='^', markersize=5, linestyle='dashed', linewidth=0.50)
plt.errorbar(x=meta_group.index,y=meta_group['Ketapril'], yerr=ketapril_met_sem, color='g', marker='s', markersize=5, linestyle='dashed', linewidth=0.50)
plt.errorbar(x=meta_group.index,y=meta_group['Placebo'], yerr=placebo_met_sem, color='k', marker='d', markersize=5, linestyle='dashed', linewidth=0.50)
plt.title('Metastatic Spread During Treatment')
plt.xlabel('Treatment Duration (Days)')
plt.ylabel('Met. Sites')
plt.legend(frameon=True)
plt.show()
```


![png](output_27_0.png)



```python
survivingmice_group = combined_df[['Timepoint','Mouse ID','Drug']]
survivingmice_group = survivingmice_group.groupby(['Drug','Timepoint']).count()
survivingmice_group.head()

```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>Mouse ID</th>
    </tr>
    <tr>
      <th>Drug</th>
      <th>Timepoint</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="5" valign="top">Capomulin</th>
      <th>0</th>
      <td>25</td>
    </tr>
    <tr>
      <th>5</th>
      <td>25</td>
    </tr>
    <tr>
      <th>10</th>
      <td>25</td>
    </tr>
    <tr>
      <th>15</th>
      <td>24</td>
    </tr>
    <tr>
      <th>20</th>
      <td>23</td>
    </tr>
  </tbody>
</table>
</div>




```python
#surviving mice pivot table
survivingmice_group = survivingmice_group.pivot_table(index='Timepoint', columns='Drug')
survivingmice_group.columns = survivingmice_group.columns.droplevel()
survivingmice_group
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Drug</th>
      <th>Capomulin</th>
      <th>Ceftamin</th>
      <th>Infubinol</th>
      <th>Ketapril</th>
      <th>Naftisol</th>
      <th>Placebo</th>
      <th>Propriva</th>
      <th>Ramicane</th>
      <th>Stelasyn</th>
      <th>Zoniferol</th>
    </tr>
    <tr>
      <th>Timepoint</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>25</td>
      <td>25</td>
      <td>25</td>
      <td>25</td>
      <td>25</td>
      <td>25</td>
      <td>26</td>
      <td>25</td>
      <td>26</td>
      <td>25</td>
    </tr>
    <tr>
      <th>5</th>
      <td>25</td>
      <td>21</td>
      <td>25</td>
      <td>23</td>
      <td>23</td>
      <td>24</td>
      <td>25</td>
      <td>25</td>
      <td>25</td>
      <td>24</td>
    </tr>
    <tr>
      <th>10</th>
      <td>25</td>
      <td>20</td>
      <td>21</td>
      <td>22</td>
      <td>21</td>
      <td>24</td>
      <td>23</td>
      <td>24</td>
      <td>23</td>
      <td>22</td>
    </tr>
    <tr>
      <th>15</th>
      <td>24</td>
      <td>19</td>
      <td>21</td>
      <td>19</td>
      <td>21</td>
      <td>20</td>
      <td>17</td>
      <td>24</td>
      <td>23</td>
      <td>21</td>
    </tr>
    <tr>
      <th>20</th>
      <td>23</td>
      <td>18</td>
      <td>20</td>
      <td>19</td>
      <td>20</td>
      <td>19</td>
      <td>17</td>
      <td>23</td>
      <td>21</td>
      <td>17</td>
    </tr>
    <tr>
      <th>25</th>
      <td>22</td>
      <td>18</td>
      <td>18</td>
      <td>19</td>
      <td>18</td>
      <td>17</td>
      <td>14</td>
      <td>23</td>
      <td>19</td>
      <td>16</td>
    </tr>
    <tr>
      <th>30</th>
      <td>22</td>
      <td>16</td>
      <td>17</td>
      <td>18</td>
      <td>15</td>
      <td>15</td>
      <td>13</td>
      <td>23</td>
      <td>18</td>
      <td>15</td>
    </tr>
    <tr>
      <th>35</th>
      <td>22</td>
      <td>14</td>
      <td>12</td>
      <td>17</td>
      <td>15</td>
      <td>14</td>
      <td>10</td>
      <td>21</td>
      <td>16</td>
      <td>14</td>
    </tr>
    <tr>
      <th>40</th>
      <td>21</td>
      <td>14</td>
      <td>10</td>
      <td>15</td>
      <td>15</td>
      <td>12</td>
      <td>9</td>
      <td>20</td>
      <td>12</td>
      <td>14</td>
    </tr>
    <tr>
      <th>45</th>
      <td>21</td>
      <td>13</td>
      <td>9</td>
      <td>11</td>
      <td>13</td>
      <td>11</td>
      <td>7</td>
      <td>20</td>
      <td>11</td>
      <td>14</td>
    </tr>
  </tbody>
</table>
</div>




```python
#chart mice survival 
plt.figure(figsize=(12,8))
plt.errorbar(x=survivingmice_group.index,y=survivingmice_group['Capomulin'], color='r', marker='o', markersize=5, linestyle='dashed', linewidth=0.50)
plt.errorbar(x=survivingmice_group.index,y=survivingmice_group['Infubinol'], color='b', marker='^', markersize=5, linestyle='dashed', linewidth=0.50)
plt.errorbar(x=survivingmice_group.index,y=survivingmice_group['Ketapril'], color='g', marker='s', markersize=5, linestyle='dashed', linewidth=0.50)
plt.errorbar(x=survivingmice_group.index,y=survivingmice_group['Placebo'], color='k', marker='d', markersize=5, linestyle='dashed', linewidth=0.50)
plt.title('Survival During Treatment')
plt.xlabel('Time (Days)')
plt.ylabel('Survival Rate (%)')
plt.legend(frameon=True)

plt.show()
```


![png](output_30_0.png)



```python
#summary bar graph
#Creating a bar graph that compares the total % tumor volume change for each drug across the full 45 days.

treatment_summary = combined_df[['Timepoint','Tumor Volume (mm3)','Drug']]
treatment_summary = treatment_summary[treatment_summary['Timepoint'].isin([0,45])]
treatment_summary = treatment_summary.groupby(['Drug', 'Timepoint'], as_index=False).mean()
treatment_summary.set_index('Drug', inplace=True)

treatment_summary
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Timepoint</th>
      <th>Tumor Volume (mm3)</th>
    </tr>
    <tr>
      <th>Drug</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Capomulin</th>
      <td>0</td>
      <td>45.000000</td>
    </tr>
    <tr>
      <th>Capomulin</th>
      <td>45</td>
      <td>36.236114</td>
    </tr>
    <tr>
      <th>Ceftamin</th>
      <td>0</td>
      <td>45.000000</td>
    </tr>
    <tr>
      <th>Ceftamin</th>
      <td>45</td>
      <td>64.132421</td>
    </tr>
    <tr>
      <th>Infubinol</th>
      <td>0</td>
      <td>45.000000</td>
    </tr>
    <tr>
      <th>Infubinol</th>
      <td>45</td>
      <td>65.755562</td>
    </tr>
    <tr>
      <th>Ketapril</th>
      <td>0</td>
      <td>45.000000</td>
    </tr>
    <tr>
      <th>Ketapril</th>
      <td>45</td>
      <td>70.662958</td>
    </tr>
    <tr>
      <th>Naftisol</th>
      <td>0</td>
      <td>45.000000</td>
    </tr>
    <tr>
      <th>Naftisol</th>
      <td>45</td>
      <td>69.265506</td>
    </tr>
    <tr>
      <th>Placebo</th>
      <td>0</td>
      <td>45.000000</td>
    </tr>
    <tr>
      <th>Placebo</th>
      <td>45</td>
      <td>68.084082</td>
    </tr>
    <tr>
      <th>Propriva</th>
      <td>0</td>
      <td>45.000000</td>
    </tr>
    <tr>
      <th>Propriva</th>
      <td>45</td>
      <td>66.258529</td>
    </tr>
    <tr>
      <th>Ramicane</th>
      <td>0</td>
      <td>45.000000</td>
    </tr>
    <tr>
      <th>Ramicane</th>
      <td>45</td>
      <td>34.955595</td>
    </tr>
    <tr>
      <th>Stelasyn</th>
      <td>0</td>
      <td>45.000000</td>
    </tr>
    <tr>
      <th>Stelasyn</th>
      <td>45</td>
      <td>68.438310</td>
    </tr>
    <tr>
      <th>Zoniferol</th>
      <td>0</td>
      <td>45.000000</td>
    </tr>
    <tr>
      <th>Zoniferol</th>
      <td>45</td>
      <td>65.960888</td>
    </tr>
  </tbody>
</table>
</div>




```python
#need to reset pct_change between drugs
#treatment_summary['Timepoint'].pct_change()

#df['pct'] = df.sort_values('Date').groupby(['Company', 'Group']).Value.pct_change()
treatment_summary['Percentage Change']=treatment_summary.groupby('Drug')['Tumor Volume (mm3)'].pct_change()*100
del treatment_summary['Tumor Volume (mm3)']
del treatment_summary['Timepoint']
treatment_summary = treatment_summary.loc[['Capomulin','Infubinol','Ketapril','Placebo']].dropna(how='any')
treatment_summary
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Percentage Change</th>
    </tr>
    <tr>
      <th>Drug</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Capomulin</th>
      <td>-19.475303</td>
    </tr>
    <tr>
      <th>Infubinol</th>
      <td>46.123472</td>
    </tr>
    <tr>
      <th>Ketapril</th>
      <td>57.028795</td>
    </tr>
    <tr>
      <th>Placebo</th>
      <td>51.297960</td>
    </tr>
  </tbody>
</table>
</div>




```python
#my_color=np.where(treatment_summary['Percentage Change']=0,'red','green')
#ax = treatment_summary.plot(kind='bar',color=my_color)
colors = [['green','red', 'red', 'red']]
ax = treatment_summary.plot(kind='bar',color=colors)
#ax=ax.map("{:,.1f}%".format <--to display percentages
plt.plot()
plt.ylabel("% Tumor Volume Change")
plt.title("Tumor Change Over 45 Day Treatment")
ax.legend_.remove()
plt.show()
```


![png](output_33_0.png)

