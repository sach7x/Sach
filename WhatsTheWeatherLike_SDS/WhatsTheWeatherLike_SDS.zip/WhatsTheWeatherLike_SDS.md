

```python
#3 observations
#From -60 to 0 degrees latitude the temperature appears to rise moderately (temp trends upwards)
#From 0 to 80 degrees latitude the temperature drops sharply (temp trends downwards)
#Overall, hottest cities lie between the -20 to 20 degree latitude range, which makes sense as cities closer to the equator are warmer
#wind speed appears the be highest at the extremes (~-60 and ~80 latitude)
```


```python
import pandas as pd
import numpy as np
import requests
import json
import matplotlib.pyplot as plt
import openweathermapy.core as owm
from citipy import citipy
from config import api_key
import urllib
api_key
```




    '3783cb16d98d47cffec41c7d2d9f754c'




```python
settings = {"appid": api_key}
```


```python
cities= [] 


lat_x = np.random.randint(-90,90, size=1200)
lon_y = np.random.randint(-180,180, size=1200)
coords = zip(lat_x,lon_y)
    

        
for lat_x, lon_y in coords:
    city = citipy.nearest_city(lat_x, lon_y).city_name


    if city not in cities:
        cities.append(city)

print('cities', len(cities))

```

    cities 510
    


```python
country = []
date = []
temperature = []
latitude = []
longitude = []
humidity = []
cloudiness = []
wind_speed = []
total_cities = []
country_code = []
weather_url = "http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=" + api_key      
i=0
for city in cities:
    try:
        i=i+1
        print(f"Processing Record {i} of {len(cities)} | {city}")
        city_url = weather_url + "&q=" + urllib.request.pathname2url(city)
        weather_json = requests.get(city_url).json()
        temperature.append(weather_json['main']['temp'])
        latitude.append(weather_json['coord']['lat'])
        date.append(weather_json['dt'])
        longitude.append(weather_json['coord']['lon'])
        humidity.append(weather_json['main']['humidity'])
        cloudiness.append(weather_json['clouds']['all'])
        wind_speed.append(weather_json['wind']['speed'])
        country_code.append(weather_json['sys']['country'])
        total_cities.append(city)
        
        print(city_url)
        
    except Exception as err:
        pass


```

    Processing Record 1 of 510 | puerto ayora
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=puerto%20ayora
    Processing Record 2 of 510 | naples
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=naples
    Processing Record 3 of 510 | cape town
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=cape%20town
    Processing Record 4 of 510 | lompoc
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=lompoc
    Processing Record 5 of 510 | new norfolk
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=new%20norfolk
    Processing Record 6 of 510 | barrow
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=barrow
    Processing Record 7 of 510 | atuona
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=atuona
    Processing Record 8 of 510 | hobart
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=hobart
    Processing Record 9 of 510 | kavieng
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=kavieng
    Processing Record 10 of 510 | rikitea
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=rikitea
    Processing Record 11 of 510 | asau
    Processing Record 12 of 510 | te anau
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=te%20anau
    Processing Record 13 of 510 | namibe
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=namibe
    Processing Record 14 of 510 | tuktoyaktuk
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=tuktoyaktuk
    Processing Record 15 of 510 | torbay
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=torbay
    Processing Record 16 of 510 | iraray
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=iraray
    Processing Record 17 of 510 | chapais
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=chapais
    Processing Record 18 of 510 | sorland
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=sorland
    Processing Record 19 of 510 | severo-kurilsk
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=severo-kurilsk
    Processing Record 20 of 510 | cefalu
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=cefalu
    Processing Record 21 of 510 | kralendijk
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=kralendijk
    Processing Record 22 of 510 | westport
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=westport
    Processing Record 23 of 510 | bethel
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=bethel
    Processing Record 24 of 510 | oxapampa
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=oxapampa
    Processing Record 25 of 510 | mataura
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=mataura
    Processing Record 26 of 510 | sentyabrskiy
    Processing Record 27 of 510 | verkhoyansk
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=verkhoyansk
    Processing Record 28 of 510 | emba
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=emba
    Processing Record 29 of 510 | juegang
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=juegang
    Processing Record 30 of 510 | alofi
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=alofi
    Processing Record 31 of 510 | poum
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=poum
    Processing Record 32 of 510 | mount gambier
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=mount%20gambier
    Processing Record 33 of 510 | beringovskiy
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=beringovskiy
    Processing Record 34 of 510 | ilulissat
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=ilulissat
    Processing Record 35 of 510 | busselton
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=busselton
    Processing Record 36 of 510 | grand river south east
    Processing Record 37 of 510 | jamestown
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=jamestown
    Processing Record 38 of 510 | itarema
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=itarema
    Processing Record 39 of 510 | tasiilaq
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=tasiilaq
    Processing Record 40 of 510 | bredasdorp
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=bredasdorp
    Processing Record 41 of 510 | albany
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=albany
    Processing Record 42 of 510 | ayan
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=ayan
    Processing Record 43 of 510 | hilo
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=hilo
    Processing Record 44 of 510 | cidreira
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=cidreira
    Processing Record 45 of 510 | saint-augustin
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=saint-augustin
    Processing Record 46 of 510 | sola
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=sola
    Processing Record 47 of 510 | oranjestad
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=oranjestad
    Processing Record 48 of 510 | pilar
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=pilar
    Processing Record 49 of 510 | kapaa
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=kapaa
    Processing Record 50 of 510 | luderitz
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=luderitz
    Processing Record 51 of 510 | fram
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=fram
    Processing Record 52 of 510 | palmer
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=palmer
    Processing Record 53 of 510 | kodiak
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=kodiak
    Processing Record 54 of 510 | guerrero negro
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=guerrero%20negro
    Processing Record 55 of 510 | miastko
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=miastko
    Processing Record 56 of 510 | machico
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=machico
    Processing Record 57 of 510 | hermanus
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=hermanus
    Processing Record 58 of 510 | yellowknife
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=yellowknife
    Processing Record 59 of 510 | esperance
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=esperance
    Processing Record 60 of 510 | dunmore east
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=dunmore%20east
    Processing Record 61 of 510 | butaritari
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=butaritari
    Processing Record 62 of 510 | castro
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=castro
    Processing Record 63 of 510 | tuatapere
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=tuatapere
    Processing Record 64 of 510 | victoria
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=victoria
    Processing Record 65 of 510 | taolanaro
    Processing Record 66 of 510 | san quintin
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=san%20quintin
    Processing Record 67 of 510 | kokopo
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=kokopo
    Processing Record 68 of 510 | san policarpo
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=san%20policarpo
    Processing Record 69 of 510 | khatanga
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=khatanga
    Processing Record 70 of 510 | mehamn
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=mehamn
    Processing Record 71 of 510 | ostrovnoy
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=ostrovnoy
    Processing Record 72 of 510 | ushuaia
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=ushuaia
    Processing Record 73 of 510 | punta arenas
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=punta%20arenas
    Processing Record 74 of 510 | port macquarie
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=port%20macquarie
    Processing Record 75 of 510 | the valley
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=the%20valley
    Processing Record 76 of 510 | tromso
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=tromso
    Processing Record 77 of 510 | anadyr
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=anadyr
    Processing Record 78 of 510 | prince rupert
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=prince%20rupert
    Processing Record 79 of 510 | grindavik
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=grindavik
    Processing Record 80 of 510 | bluff
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=bluff
    Processing Record 81 of 510 | chuy
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=chuy
    Processing Record 82 of 510 | illoqqortoormiut
    Processing Record 83 of 510 | geraldton
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=geraldton
    Processing Record 84 of 510 | faanui
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=faanui
    Processing Record 85 of 510 | bambous virieux
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=bambous%20virieux
    Processing Record 86 of 510 | norman wells
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=norman%20wells
    Processing Record 87 of 510 | isangel
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=isangel
    Processing Record 88 of 510 | nizhneyansk
    Processing Record 89 of 510 | broken hill
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=broken%20hill
    Processing Record 90 of 510 | santa maria da vitoria
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=santa%20maria%20da%20vitoria
    Processing Record 91 of 510 | nyrad
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=nyrad
    Processing Record 92 of 510 | brae
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=brae
    Processing Record 93 of 510 | samarai
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=samarai
    Processing Record 94 of 510 | maceio
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=maceio
    Processing Record 95 of 510 | cherskiy
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=cherskiy
    Processing Record 96 of 510 | saleaula
    Processing Record 97 of 510 | amderma
    Processing Record 98 of 510 | hasaki
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=hasaki
    Processing Record 99 of 510 | mys shmidta
    Processing Record 100 of 510 | longonjo
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=longonjo
    Processing Record 101 of 510 | egvekinot
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=egvekinot
    Processing Record 102 of 510 | bathsheba
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=bathsheba
    Processing Record 103 of 510 | tautira
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=tautira
    Processing Record 104 of 510 | kisanga
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=kisanga
    Processing Record 105 of 510 | colinas
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=colinas
    Processing Record 106 of 510 | itaituba
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=itaituba
    Processing Record 107 of 510 | georgetown
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=georgetown
    Processing Record 108 of 510 | novyy urengoy
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=novyy%20urengoy
    Processing Record 109 of 510 | tashara
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=tashara
    Processing Record 110 of 510 | longyearbyen
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=longyearbyen
    Processing Record 111 of 510 | qaanaaq
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=qaanaaq
    Processing Record 112 of 510 | mocajuba
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=mocajuba
    Processing Record 113 of 510 | vaini
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=vaini
    Processing Record 114 of 510 | semey
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=semey
    Processing Record 115 of 510 | palabuhanratu
    Processing Record 116 of 510 | lasa
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=lasa
    Processing Record 117 of 510 | rawson
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=rawson
    Processing Record 118 of 510 | mar del plata
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=mar%20del%20plata
    Processing Record 119 of 510 | margate
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=margate
    Processing Record 120 of 510 | itoman
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=itoman
    Processing Record 121 of 510 | nsunga
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=nsunga
    Processing Record 122 of 510 | tual
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=tual
    Processing Record 123 of 510 | seymchan
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=seymchan
    Processing Record 124 of 510 | yambio
    Processing Record 125 of 510 | khandbari
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=khandbari
    Processing Record 126 of 510 | pokosnoye
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=pokosnoye
    Processing Record 127 of 510 | alice springs
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=alice%20springs
    Processing Record 128 of 510 | souillac
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=souillac
    Processing Record 129 of 510 | port alfred
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=port%20alfred
    Processing Record 130 of 510 | nikolskoye
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=nikolskoye
    Processing Record 131 of 510 | rapid valley
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=rapid%20valley
    Processing Record 132 of 510 | zhangye
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=zhangye
    Processing Record 133 of 510 | grande-riviere
    Processing Record 134 of 510 | nagato
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=nagato
    Processing Record 135 of 510 | cabo san lucas
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=cabo%20san%20lucas
    Processing Record 136 of 510 | beloha
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=beloha
    Processing Record 137 of 510 | half moon bay
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=half%20moon%20bay
    Processing Record 138 of 510 | tura
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=tura
    Processing Record 139 of 510 | smithers
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=smithers
    Processing Record 140 of 510 | bengkulu
    Processing Record 141 of 510 | umzimvubu
    Processing Record 142 of 510 | port elizabeth
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=port%20elizabeth
    Processing Record 143 of 510 | yamada
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=yamada
    Processing Record 144 of 510 | peniche
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=peniche
    Processing Record 145 of 510 | hamilton
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=hamilton
    Processing Record 146 of 510 | lebedinyy
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=lebedinyy
    Processing Record 147 of 510 | oros
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=oros
    Processing Record 148 of 510 | lima
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=lima
    Processing Record 149 of 510 | hagersville
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=hagersville
    Processing Record 150 of 510 | kahului
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=kahului
    Processing Record 151 of 510 | ponta do sol
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=ponta%20do%20sol
    Processing Record 152 of 510 | kaitangata
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=kaitangata
    Processing Record 153 of 510 | port blair
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=port%20blair
    Processing Record 154 of 510 | kuche
    Processing Record 155 of 510 | airai
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=airai
    Processing Record 156 of 510 | pisco
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=pisco
    Processing Record 157 of 510 | ketchikan
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=ketchikan
    Processing Record 158 of 510 | ribeira grande
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=ribeira%20grande
    Processing Record 159 of 510 | saskylakh
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=saskylakh
    Processing Record 160 of 510 | avarua
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=avarua
    Processing Record 161 of 510 | san patricio
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=san%20patricio
    Processing Record 162 of 510 | nuuk
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=nuuk
    Processing Record 163 of 510 | bemidji
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=bemidji
    Processing Record 164 of 510 | lorengau
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=lorengau
    Processing Record 165 of 510 | riyadh
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=riyadh
    Processing Record 166 of 510 | magomeni
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=magomeni
    Processing Record 167 of 510 | harnosand
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=harnosand
    Processing Record 168 of 510 | mao
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=mao
    Processing Record 169 of 510 | attawapiskat
    Processing Record 170 of 510 | micheweni
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=micheweni
    Processing Record 171 of 510 | grand gaube
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=grand%20gaube
    Processing Record 172 of 510 | arraial do cabo
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=arraial%20do%20cabo
    Processing Record 173 of 510 | tanete
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=tanete
    Processing Record 174 of 510 | saint-pierre
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=saint-pierre
    Processing Record 175 of 510 | ahuimanu
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=ahuimanu
    Processing Record 176 of 510 | port hardy
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=port%20hardy
    Processing Record 177 of 510 | manzhouli
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=manzhouli
    Processing Record 178 of 510 | riberalta
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=riberalta
    Processing Record 179 of 510 | san andres
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=san%20andres
    Processing Record 180 of 510 | bardiyah
    Processing Record 181 of 510 | machinga
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=machinga
    Processing Record 182 of 510 | sitka
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=sitka
    Processing Record 183 of 510 | lebu
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=lebu
    Processing Record 184 of 510 | pipri
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=pipri
    Processing Record 185 of 510 | baykit
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=baykit
    Processing Record 186 of 510 | esmeraldas
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=esmeraldas
    Processing Record 187 of 510 | dakoro
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=dakoro
    Processing Record 188 of 510 | porto belo
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=porto%20belo
    Processing Record 189 of 510 | plettenberg bay
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=plettenberg%20bay
    Processing Record 190 of 510 | adrar
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=adrar
    Processing Record 191 of 510 | macaboboni
    Processing Record 192 of 510 | litovko
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=litovko
    Processing Record 193 of 510 | rawannawi
    Processing Record 194 of 510 | concarneau
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=concarneau
    Processing Record 195 of 510 | awjilah
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=awjilah
    Processing Record 196 of 510 | sobolevo
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=sobolevo
    Processing Record 197 of 510 | povenets
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=povenets
    Processing Record 198 of 510 | wani
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=wani
    Processing Record 199 of 510 | upernavik
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=upernavik
    Processing Record 200 of 510 | port arthur
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=port%20arthur
    Processing Record 201 of 510 | san cristobal
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=san%20cristobal
    Processing Record 202 of 510 | narsaq
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=narsaq
    Processing Record 203 of 510 | visby
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=visby
    Processing Record 204 of 510 | ambunti
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=ambunti
    Processing Record 205 of 510 | challans
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=challans
    Processing Record 206 of 510 | sao tome
    Processing Record 207 of 510 | kutum
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=kutum
    Processing Record 208 of 510 | baboua
    Processing Record 209 of 510 | quesnel
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=quesnel
    Processing Record 210 of 510 | benghazi
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=benghazi
    Processing Record 211 of 510 | tessalit
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=tessalit
    Processing Record 212 of 510 | sassandra
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=sassandra
    Processing Record 213 of 510 | kastamonu
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=kastamonu
    Processing Record 214 of 510 | agadez
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=agadez
    Processing Record 215 of 510 | clervaux
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=clervaux
    Processing Record 216 of 510 | terryville
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=terryville
    Processing Record 217 of 510 | dikson
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=dikson
    Processing Record 218 of 510 | aklavik
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=aklavik
    Processing Record 219 of 510 | warqla
    Processing Record 220 of 510 | mogwase
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=mogwase
    Processing Record 221 of 510 | lagoa
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=lagoa
    Processing Record 222 of 510 | mahebourg
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=mahebourg
    Processing Record 223 of 510 | dumbraveni
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=dumbraveni
    Processing Record 224 of 510 | yulara
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=yulara
    Processing Record 225 of 510 | kerman
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=kerman
    Processing Record 226 of 510 | qaqortoq
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=qaqortoq
    Processing Record 227 of 510 | east london
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=east%20london
    Processing Record 228 of 510 | hovd
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=hovd
    Processing Record 229 of 510 | hofn
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=hofn
    Processing Record 230 of 510 | luba
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=luba
    Processing Record 231 of 510 | katobu
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=katobu
    Processing Record 232 of 510 | tasbuget
    Processing Record 233 of 510 | jiupu
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=jiupu
    Processing Record 234 of 510 | taree
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=taree
    Processing Record 235 of 510 | saint george
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=saint%20george
    Processing Record 236 of 510 | taltal
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=taltal
    Processing Record 237 of 510 | togur
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=togur
    Processing Record 238 of 510 | puerto carreno
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=puerto%20carreno
    Processing Record 239 of 510 | clyde river
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=clyde%20river
    Processing Record 240 of 510 | acarau
    Processing Record 241 of 510 | storforshei
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=storforshei
    Processing Record 242 of 510 | provideniya
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=provideniya
    Processing Record 243 of 510 | nueva loja
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=nueva%20loja
    Processing Record 244 of 510 | zverinogolovskoye
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=zverinogolovskoye
    Processing Record 245 of 510 | kaduqli
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=kaduqli
    Processing Record 246 of 510 | dingle
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=dingle
    Processing Record 247 of 510 | maues
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=maues
    Processing Record 248 of 510 | witbank
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=witbank
    Processing Record 249 of 510 | tsihombe
    Processing Record 250 of 510 | komsomolskiy
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=komsomolskiy
    Processing Record 251 of 510 | madang
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=madang
    Processing Record 252 of 510 | saldanha
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=saldanha
    Processing Record 253 of 510 | nemuro
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=nemuro
    Processing Record 254 of 510 | linchuan
    Processing Record 255 of 510 | belushya guba
    Processing Record 256 of 510 | yar-sale
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=yar-sale
    Processing Record 257 of 510 | banatski karlovac
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=banatski%20karlovac
    Processing Record 258 of 510 | vuktyl
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=vuktyl
    Processing Record 259 of 510 | biloela
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=biloela
    Processing Record 260 of 510 | thompson
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=thompson
    Processing Record 261 of 510 | tumannyy
    Processing Record 262 of 510 | saint-philippe
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=saint-philippe
    Processing Record 263 of 510 | los llanos de aridane
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=los%20llanos%20de%20aridane
    Processing Record 264 of 510 | caravelas
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=caravelas
    Processing Record 265 of 510 | alekseyevsk
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=alekseyevsk
    Processing Record 266 of 510 | sur
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=sur
    Processing Record 267 of 510 | zhuanghe
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=zhuanghe
    Processing Record 268 of 510 | klaksvik
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=klaksvik
    Processing Record 269 of 510 | hambantota
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=hambantota
    Processing Record 270 of 510 | karaul
    Processing Record 271 of 510 | basoko
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=basoko
    Processing Record 272 of 510 | ati
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=ati
    Processing Record 273 of 510 | yenisea
    Processing Record 274 of 510 | porto torres
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=porto%20torres
    Processing Record 275 of 510 | olafsvik
    Processing Record 276 of 510 | fairbanks
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=fairbanks
    Processing Record 277 of 510 | padang
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=padang
    Processing Record 278 of 510 | rio gallegos
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=rio%20gallegos
    Processing Record 279 of 510 | pevek
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=pevek
    Processing Record 280 of 510 | korla
    Processing Record 281 of 510 | leningradskiy
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=leningradskiy
    Processing Record 282 of 510 | sao filipe
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=sao%20filipe
    Processing Record 283 of 510 | omboue
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=omboue
    Processing Record 284 of 510 | vaitupu
    Processing Record 285 of 510 | akdepe
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=akdepe
    Processing Record 286 of 510 | lujiang
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=lujiang
    Processing Record 287 of 510 | marcona
    Processing Record 288 of 510 | dutlwe
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=dutlwe
    Processing Record 289 of 510 | mackenzie
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=mackenzie
    Processing Record 290 of 510 | tawnat
    Processing Record 291 of 510 | xiaoweizhai
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=xiaoweizhai
    Processing Record 292 of 510 | natal
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=natal
    Processing Record 293 of 510 | inta
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=inta
    Processing Record 294 of 510 | mandali
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=mandali
    Processing Record 295 of 510 | el dorado
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=el%20dorado
    Processing Record 296 of 510 | husavik
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=husavik
    Processing Record 297 of 510 | bargal
    Processing Record 298 of 510 | kalianget
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=kalianget
    Processing Record 299 of 510 | campohermoso
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=campohermoso
    Processing Record 300 of 510 | coquimbo
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=coquimbo
    Processing Record 301 of 510 | salalah
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=salalah
    Processing Record 302 of 510 | portland
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=portland
    Processing Record 303 of 510 | nyurba
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=nyurba
    Processing Record 304 of 510 | aleksandrovka
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=aleksandrovka
    Processing Record 305 of 510 | vyshestebliyevskaya
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=vyshestebliyevskaya
    Processing Record 306 of 510 | nanortalik
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=nanortalik
    Processing Record 307 of 510 | kyren
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=kyren
    Processing Record 308 of 510 | saint anthony
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=saint%20anthony
    Processing Record 309 of 510 | noumea
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=noumea
    Processing Record 310 of 510 | waddan
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=waddan
    Processing Record 311 of 510 | baisha
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=baisha
    Processing Record 312 of 510 | kirovskiy
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=kirovskiy
    Processing Record 313 of 510 | coahuayana
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=coahuayana
    Processing Record 314 of 510 | amberley
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=amberley
    Processing Record 315 of 510 | payo
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=payo
    Processing Record 316 of 510 | wajima
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=wajima
    Processing Record 317 of 510 | atambua
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=atambua
    Processing Record 318 of 510 | matay
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=matay
    Processing Record 319 of 510 | kimbe
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=kimbe
    Processing Record 320 of 510 | nouadhibou
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=nouadhibou
    Processing Record 321 of 510 | gamba
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=gamba
    Processing Record 322 of 510 | hithadhoo
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=hithadhoo
    Processing Record 323 of 510 | barentsburg
    Processing Record 324 of 510 | vardo
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=vardo
    Processing Record 325 of 510 | najran
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=najran
    Processing Record 326 of 510 | goderich
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=goderich
    Processing Record 327 of 510 | nouakchott
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=nouakchott
    Processing Record 328 of 510 | ellisras
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=ellisras
    Processing Record 329 of 510 | gwadar
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=gwadar
    Processing Record 330 of 510 | tuljapur
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=tuljapur
    Processing Record 331 of 510 | pasighat
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=pasighat
    Processing Record 332 of 510 | dekar
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=dekar
    Processing Record 333 of 510 | barkhan
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=barkhan
    Processing Record 334 of 510 | umba
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=umba
    Processing Record 335 of 510 | necochea
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=necochea
    Processing Record 336 of 510 | palatka
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=palatka
    Processing Record 337 of 510 | wanaka
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=wanaka
    Processing Record 338 of 510 | sorong
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=sorong
    Processing Record 339 of 510 | westpunt
    Processing Record 340 of 510 | talara
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=talara
    Processing Record 341 of 510 | port-cartier
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=port-cartier
    Processing Record 342 of 510 | tuzla
    Processing Record 343 of 510 | parral
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=parral
    Processing Record 344 of 510 | simao
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=simao
    Processing Record 345 of 510 | raudeberg
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=raudeberg
    Processing Record 346 of 510 | ndele
    Processing Record 347 of 510 | deep river
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=deep%20river
    Processing Record 348 of 510 | arkhangelsk
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=arkhangelsk
    Processing Record 349 of 510 | palu
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=palu
    Processing Record 350 of 510 | vao
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=vao
    Processing Record 351 of 510 | matagami
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=matagami
    Processing Record 352 of 510 | zhuhai
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=zhuhai
    Processing Record 353 of 510 | chimbote
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=chimbote
    Processing Record 354 of 510 | nguiu
    Processing Record 355 of 510 | florian
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=florian
    Processing Record 356 of 510 | sarreguemines
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=sarreguemines
    Processing Record 357 of 510 | vestmannaeyjar
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=vestmannaeyjar
    Processing Record 358 of 510 | ust-nera
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=ust-nera
    Processing Record 359 of 510 | nam tha
    Processing Record 360 of 510 | idritsa
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=idritsa
    Processing Record 361 of 510 | nome
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=nome
    Processing Record 362 of 510 | quatre cocos
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=quatre%20cocos
    Processing Record 363 of 510 | torata
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=torata
    Processing Record 364 of 510 | havre-saint-pierre
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=havre-saint-pierre
    Processing Record 365 of 510 | saint-francois
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=saint-francois
    Processing Record 366 of 510 | galiwinku
    Processing Record 367 of 510 | fortuna
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=fortuna
    Processing Record 368 of 510 | tunceli
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=tunceli
    Processing Record 369 of 510 | lavrentiya
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=lavrentiya
    Processing Record 370 of 510 | cockburn town
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=cockburn%20town
    Processing Record 371 of 510 | tazovskiy
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=tazovskiy
    Processing Record 372 of 510 | ondjiva
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=ondjiva
    Processing Record 373 of 510 | joshimath
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=joshimath
    Processing Record 374 of 510 | safaga
    Processing Record 375 of 510 | brownsville
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=brownsville
    Processing Record 376 of 510 | nalut
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=nalut
    Processing Record 377 of 510 | apomu
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=apomu
    Processing Record 378 of 510 | taburi
    Processing Record 379 of 510 | krasnoselkup
    Processing Record 380 of 510 | carnarvon
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=carnarvon
    Processing Record 381 of 510 | amga
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=amga
    Processing Record 382 of 510 | lata
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=lata
    Processing Record 383 of 510 | sambava
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=sambava
    Processing Record 384 of 510 | huaibei
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=huaibei
    Processing Record 385 of 510 | marawi
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=marawi
    Processing Record 386 of 510 | namtsy
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=namtsy
    Processing Record 387 of 510 | dubovka
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=dubovka
    Processing Record 388 of 510 | temascalcingo
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=temascalcingo
    Processing Record 389 of 510 | baherden
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=baherden
    Processing Record 390 of 510 | puerto madero
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=puerto%20madero
    Processing Record 391 of 510 | kanchanaburi
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=kanchanaburi
    Processing Record 392 of 510 | chabahar
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=chabahar
    Processing Record 393 of 510 | asfi
    Processing Record 394 of 510 | lexington
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=lexington
    Processing Record 395 of 510 | baruun-urt
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=baruun-urt
    Processing Record 396 of 510 | kedrovyy
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=kedrovyy
    Processing Record 397 of 510 | abha
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=abha
    Processing Record 398 of 510 | lerik
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=lerik
    Processing Record 399 of 510 | wanning
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=wanning
    Processing Record 400 of 510 | mamakan
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=mamakan
    Processing Record 401 of 510 | iqaluit
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=iqaluit
    Processing Record 402 of 510 | maniitsoq
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=maniitsoq
    Processing Record 403 of 510 | atar
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=atar
    Processing Record 404 of 510 | biltine
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=biltine
    Processing Record 405 of 510 | ambilobe
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=ambilobe
    Processing Record 406 of 510 | srednekolymsk
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=srednekolymsk
    Processing Record 407 of 510 | iskateley
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=iskateley
    Processing Record 408 of 510 | richards bay
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=richards%20bay
    Processing Record 409 of 510 | naze
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=naze
    Processing Record 410 of 510 | manokwari
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=manokwari
    Processing Record 411 of 510 | esfahan
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=esfahan
    Processing Record 412 of 510 | dunedin
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=dunedin
    Processing Record 413 of 510 | alvinopolis
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=alvinopolis
    Processing Record 414 of 510 | subiaco
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=subiaco
    Processing Record 415 of 510 | san-pedro
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=san-pedro
    Processing Record 416 of 510 | katsuura
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=katsuura
    Processing Record 417 of 510 | raga
    Processing Record 418 of 510 | shelburne
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=shelburne
    Processing Record 419 of 510 | carutapera
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=carutapera
    Processing Record 420 of 510 | van
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=van
    Processing Record 421 of 510 | yilan
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=yilan
    Processing Record 422 of 510 | cayenne
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=cayenne
    Processing Record 423 of 510 | biak
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=biak
    Processing Record 424 of 510 | dongsheng
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=dongsheng
    Processing Record 425 of 510 | dali
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=dali
    Processing Record 426 of 510 | tzucacab
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=tzucacab
    Processing Record 427 of 510 | comodoro rivadavia
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=comodoro%20rivadavia
    Processing Record 428 of 510 | jalu
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=jalu
    Processing Record 429 of 510 | homer
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=homer
    Processing Record 430 of 510 | novikovo
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=novikovo
    Processing Record 431 of 510 | healdsburg
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=healdsburg
    Processing Record 432 of 510 | okhotsk
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=okhotsk
    Processing Record 433 of 510 | lebrija
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=lebrija
    Processing Record 434 of 510 | almeirim
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=almeirim
    Processing Record 435 of 510 | binga
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=binga
    Processing Record 436 of 510 | sijunjung
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=sijunjung
    Processing Record 437 of 510 | saint-andre-les-vergers
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=saint-andre-les-vergers
    Processing Record 438 of 510 | jumla
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=jumla
    Processing Record 439 of 510 | gat
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=gat
    Processing Record 440 of 510 | great yarmouth
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=great%20yarmouth
    Processing Record 441 of 510 | piranshahr
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=piranshahr
    Processing Record 442 of 510 | kununurra
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=kununurra
    Processing Record 443 of 510 | omaruru
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=omaruru
    Processing Record 444 of 510 | slave lake
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=slave%20lake
    Processing Record 445 of 510 | troitsko-pechorsk
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=troitsko-pechorsk
    Processing Record 446 of 510 | wattegama
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=wattegama
    Processing Record 447 of 510 | beterou
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=beterou
    Processing Record 448 of 510 | linfen
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=linfen
    Processing Record 449 of 510 | smirnykh
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=smirnykh
    Processing Record 450 of 510 | bukachacha
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=bukachacha
    Processing Record 451 of 510 | kichera
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=kichera
    Processing Record 452 of 510 | braganca
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=braganca
    Processing Record 453 of 510 | kuytun
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=kuytun
    Processing Record 454 of 510 | zerbst
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=zerbst
    Processing Record 455 of 510 | lucea
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=lucea
    Processing Record 456 of 510 | kaspiysk
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=kaspiysk
    Processing Record 457 of 510 | anloga
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=anloga
    Processing Record 458 of 510 | belaya gora
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=belaya%20gora
    Processing Record 459 of 510 | kamennomostskiy
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=kamennomostskiy
    Processing Record 460 of 510 | saravan
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=saravan
    Processing Record 461 of 510 | udachnyy
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=udachnyy
    Processing Record 462 of 510 | buala
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=buala
    Processing Record 463 of 510 | alpena
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=alpena
    Processing Record 464 of 510 | xining
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=xining
    Processing Record 465 of 510 | hami
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=hami
    Processing Record 466 of 510 | tiksi
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=tiksi
    Processing Record 467 of 510 | shahrud
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=shahrud
    Processing Record 468 of 510 | bandarbeyla
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=bandarbeyla
    Processing Record 469 of 510 | presidente medici
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=presidente%20medici
    Processing Record 470 of 510 | tres lagoas
    Processing Record 471 of 510 | stornoway
    Processing Record 472 of 510 | ijaki
    Processing Record 473 of 510 | zaysan
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=zaysan
    Processing Record 474 of 510 | vila velha
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=vila%20velha
    Processing Record 475 of 510 | atkarsk
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=atkarsk
    Processing Record 476 of 510 | shu
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=shu
    Processing Record 477 of 510 | cap-aux-meules
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=cap-aux-meules
    Processing Record 478 of 510 | agogo
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=agogo
    Processing Record 479 of 510 | shingu
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=shingu
    Processing Record 480 of 510 | rockport
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=rockport
    Processing Record 481 of 510 | barillas
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=barillas
    Processing Record 482 of 510 | sansai
    Processing Record 483 of 510 | antofagasta
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=antofagasta
    Processing Record 484 of 510 | faya
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=faya
    Processing Record 485 of 510 | namie
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=namie
    Processing Record 486 of 510 | santa maria
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=santa%20maria
    Processing Record 487 of 510 | mangan
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=mangan
    Processing Record 488 of 510 | lakselv
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=lakselv
    Processing Record 489 of 510 | vostok
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=vostok
    Processing Record 490 of 510 | berlevag
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=berlevag
    Processing Record 491 of 510 | satitoa
    Processing Record 492 of 510 | ust-bolsheretsk
    Processing Record 493 of 510 | sao joao da barra
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=sao%20joao%20da%20barra
    Processing Record 494 of 510 | linxia
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=linxia
    Processing Record 495 of 510 | aykhal
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=aykhal
    Processing Record 496 of 510 | williams lake
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=williams%20lake
    Processing Record 497 of 510 | pontal
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=pontal
    Processing Record 498 of 510 | ngukurr
    Processing Record 499 of 510 | kamaishi
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=kamaishi
    Processing Record 500 of 510 | gushikawa
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=gushikawa
    Processing Record 501 of 510 | phalombe
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=phalombe
    Processing Record 502 of 510 | basco
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=basco
    Processing Record 503 of 510 | falealupo
    Processing Record 504 of 510 | kembe
    Processing Record 505 of 510 | hagere hiywet
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=hagere%20hiywet
    Processing Record 506 of 510 | sigli
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=sigli
    Processing Record 507 of 510 | savannah bight
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=savannah%20bight
    Processing Record 508 of 510 | constitucion
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=constitucion
    Processing Record 509 of 510 | tabas
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=tabas
    Processing Record 510 of 510 | helena
    http://api.openweathermap.org/data/2.5/weather?units=Imperial&APPID=3783cb16d98d47cffec41c7d2d9f754c&q=helena
    


```python
weather_df = pd.DataFrame({'Cities':total_cities,
                          'Temperature':temperature,
                          'Latitude':latitude,
                          'Longitude':longitude,
                          'Humidity':humidity,
                          'Cloudiness':cloudiness,
                          'Wind Speed':wind_speed,
                           'Country Code':country_code
                          })
weather_df.to_csv('WhatsTheWeatherLike_SDS.csv')
weather_df.head(20)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Cities</th>
      <th>Cloudiness</th>
      <th>Country Code</th>
      <th>Humidity</th>
      <th>Latitude</th>
      <th>Longitude</th>
      <th>Temperature</th>
      <th>Wind Speed</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>puerto ayora</td>
      <td>44</td>
      <td>EC</td>
      <td>100</td>
      <td>-0.74</td>
      <td>-90.35</td>
      <td>75.26</td>
      <td>6.06</td>
    </tr>
    <tr>
      <th>1</th>
      <td>naples</td>
      <td>90</td>
      <td>US</td>
      <td>78</td>
      <td>26.14</td>
      <td>-81.79</td>
      <td>71.55</td>
      <td>2.71</td>
    </tr>
    <tr>
      <th>2</th>
      <td>cape town</td>
      <td>0</td>
      <td>ZA</td>
      <td>77</td>
      <td>-33.93</td>
      <td>18.42</td>
      <td>64.40</td>
      <td>5.82</td>
    </tr>
    <tr>
      <th>3</th>
      <td>lompoc</td>
      <td>90</td>
      <td>US</td>
      <td>87</td>
      <td>34.64</td>
      <td>-120.46</td>
      <td>51.80</td>
      <td>3.36</td>
    </tr>
    <tr>
      <th>4</th>
      <td>new norfolk</td>
      <td>20</td>
      <td>AU</td>
      <td>40</td>
      <td>-42.78</td>
      <td>147.06</td>
      <td>69.80</td>
      <td>17.22</td>
    </tr>
    <tr>
      <th>5</th>
      <td>barrow</td>
      <td>0</td>
      <td>AR</td>
      <td>91</td>
      <td>-38.31</td>
      <td>-60.23</td>
      <td>54.56</td>
      <td>9.19</td>
    </tr>
    <tr>
      <th>6</th>
      <td>atuona</td>
      <td>68</td>
      <td>PF</td>
      <td>100</td>
      <td>-9.80</td>
      <td>-139.03</td>
      <td>81.38</td>
      <td>16.35</td>
    </tr>
    <tr>
      <th>7</th>
      <td>hobart</td>
      <td>20</td>
      <td>AU</td>
      <td>40</td>
      <td>-42.88</td>
      <td>147.33</td>
      <td>69.80</td>
      <td>17.22</td>
    </tr>
    <tr>
      <th>8</th>
      <td>kavieng</td>
      <td>12</td>
      <td>PG</td>
      <td>100</td>
      <td>-2.57</td>
      <td>150.80</td>
      <td>84.44</td>
      <td>8.19</td>
    </tr>
    <tr>
      <th>9</th>
      <td>rikitea</td>
      <td>20</td>
      <td>PF</td>
      <td>100</td>
      <td>-23.12</td>
      <td>-134.97</td>
      <td>79.04</td>
      <td>4.94</td>
    </tr>
    <tr>
      <th>10</th>
      <td>te anau</td>
      <td>80</td>
      <td>NZ</td>
      <td>91</td>
      <td>-45.41</td>
      <td>167.72</td>
      <td>51.32</td>
      <td>17.02</td>
    </tr>
    <tr>
      <th>11</th>
      <td>namibe</td>
      <td>68</td>
      <td>AO</td>
      <td>100</td>
      <td>-15.19</td>
      <td>12.15</td>
      <td>78.14</td>
      <td>1.48</td>
    </tr>
    <tr>
      <th>12</th>
      <td>tuktoyaktuk</td>
      <td>76</td>
      <td>CA</td>
      <td>78</td>
      <td>69.44</td>
      <td>-133.03</td>
      <td>-3.03</td>
      <td>9.17</td>
    </tr>
    <tr>
      <th>13</th>
      <td>torbay</td>
      <td>90</td>
      <td>CA</td>
      <td>74</td>
      <td>47.66</td>
      <td>-52.73</td>
      <td>28.40</td>
      <td>8.05</td>
    </tr>
    <tr>
      <th>14</th>
      <td>iraray</td>
      <td>32</td>
      <td>PH</td>
      <td>95</td>
      <td>8.99</td>
      <td>118.05</td>
      <td>84.35</td>
      <td>10.42</td>
    </tr>
    <tr>
      <th>15</th>
      <td>chapais</td>
      <td>90</td>
      <td>CA</td>
      <td>71</td>
      <td>49.78</td>
      <td>-74.86</td>
      <td>6.80</td>
      <td>4.70</td>
    </tr>
    <tr>
      <th>16</th>
      <td>sorland</td>
      <td>40</td>
      <td>NO</td>
      <td>100</td>
      <td>67.67</td>
      <td>12.69</td>
      <td>22.17</td>
      <td>8.05</td>
    </tr>
    <tr>
      <th>17</th>
      <td>severo-kurilsk</td>
      <td>92</td>
      <td>RU</td>
      <td>99</td>
      <td>50.68</td>
      <td>156.12</td>
      <td>31.25</td>
      <td>18.14</td>
    </tr>
    <tr>
      <th>18</th>
      <td>cefalu</td>
      <td>20</td>
      <td>IT</td>
      <td>100</td>
      <td>38.04</td>
      <td>14.02</td>
      <td>39.71</td>
      <td>2.04</td>
    </tr>
    <tr>
      <th>19</th>
      <td>kralendijk</td>
      <td>92</td>
      <td>BQ</td>
      <td>78</td>
      <td>12.15</td>
      <td>-68.27</td>
      <td>78.80</td>
      <td>9.17</td>
    </tr>
  </tbody>
</table>
</div>




```python
lat_temp = plt.scatter(x=weather_df['Latitude'], y=weather_df['Temperature'], alpha=1)
plt.xlabel('Latitude')
plt.ylabel('Max Temperature (F)')
plt.title('City Latitude vs. Max Temperature (4/2/2018)')
plt.grid(True)
plt.show()
plt.savefig('City Latitude vs Max Temperature.png')
```


![png](output_6_0.png)



    <matplotlib.figure.Figure at 0x2d1a5256358>



```python
hum_lat = plt.scatter(x=weather_df['Latitude'], y=weather_df['Humidity'], color='blue', alpha=1.0)
plt.xlabel('Latitude')
plt.ylabel('Humidity(%)')
plt.title('City Latitude vs. Humidity (4/2/2018)')
plt.grid(True)
plt.show()
plt.savefig('City Latitude vs Humidity.png')
```


![png](output_7_0.png)



    <matplotlib.figure.Figure at 0x2d1a666acf8>



```python
cloud_lat = plt.scatter(x=weather_df['Latitude'], y=weather_df['Cloudiness'], color='blue', alpha=1.0)
plt.xlabel('Latitude')
plt.ylabel('Cloudiness (%)')
plt.title('City Latitude vs. Cloudiness (4/2/2018)')
plt.grid(True)
plt.show()
plt.savefig('City Latitude vs Cloudiness.png')
```


![png](output_8_0.png)



    <matplotlib.figure.Figure at 0x2d1a6660cf8>



```python
wind_lat = plt.scatter(x=weather_df['Latitude'], y=weather_df['Wind Speed'], color='blue', alpha=1.0)
plt.xlabel('Latitude')
plt.ylabel('Wind Speed (mph)')
plt.title('City Latitude vs. Wind Speed (4/2/2018)')
plt.grid(True)
plt.show()
plt.savefig('City Latitude vs Wind Speed.png')
```


![png](output_9_0.png)



    <matplotlib.figure.Figure at 0x2d1a6753da0>

